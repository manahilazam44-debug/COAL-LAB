.model small
.stack 100h
.data
    msg1 db 'Enter 5 numbers: $'
    msg2 db 13, 10, 'Largest number is: $'
    newline db 13, 10, '$'
    arr dw 5 dup(?)
    largest dw 0

.code
main proc
    mov ax, @data
    mov ds, ax

    lea dx, msg1
    mov ah, 9
    int 21h

    mov cx, 5
    lea si, arr
    
input_loop:
    call read_number
    mov [si], ax
    add si, 2
    loop input_loop

    lea si, arr
    mov ax, [si]
    mov largest, ax
    mov cx, 4
    add si, 2
    
find_largest:
    mov ax, [si]
    cmp ax, largest
    jle not_larger
    mov largest, ax
    
not_larger:
    add si, 2
    loop find_largest

    lea dx, msg2
    mov ah, 9
    int 21h
    
    mov ax, largest
    call print_number
    
    mov ah, 4ch
    int 21h
main endp

read_number proc
    push bx
    push cx
    push dx
    
    mov bx, 0
    
read_char:
    mov ah, 1
    int 21h
    cmp al, 13
    je done_read
    cmp al, ' '
    je done_read
    sub al, 48
    mov cl, al
    mov ax, bx
    mov bx, 10
    mul bx
    add ax, cx
    mov bx, ax
    jmp read_char
    
done_read:
    mov ax, bx
    pop dx
    pop cx
    pop bx
    ret
read_number endp

print_number proc
    push ax
    push bx
    push cx
    push dx
    
    cmp ax, 0
    jne not_zero
    mov dl, '0'
    mov ah, 2
    int 21h
    jmp print_done
    
not_zero:
    mov bx, 10
    xor cx, cx
    
convert:
    xor dx, dx
    div bx
    push dx
    inc cx
    cmp ax, 0
    jne convert
    
print_digits:
    pop dx
    add dl, 48
    mov ah, 2
    int 21h
    loop print_digits
    
print_done:
    pop dx
    pop cx
    pop bx
    pop ax
    ret
print_number endp

end main



