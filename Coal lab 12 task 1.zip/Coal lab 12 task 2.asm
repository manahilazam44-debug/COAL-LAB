.model small
.stack 100h

.data
    newline db 13, 10, '$'
    space   db ' ', '$'

.code
main proc
    mov ax, @data
    mov ds, ax
    
    mov cx, 5          
    mov si, 1          
    
row_start:
    push cx           
    mov cx, 5          
    mov di, 1       
    
col_start:
    mov ax, si         
    mul di             
    call print_num   
    
    lea dx, space
    mov ah, 9
    int 21h
    
    inc di            
    loop col_start
    
    lea dx, newline
    mov ah, 9
    int 21h
    
    inc si         
    pop cx         
    loop row_start
    
    mov ah, 4ch
    int 21h
    
main endp

print_num proc
    push ax
    push bx
    push cx
    push dx
    
    mov bx, 10         
    
    cmp ax, 9
    jbe single_digit

    xor cx, cx          
    
divide_loop:
    xor dx, dx         
    div bx            
    push dx           
    inc cx            
    cmp ax, 0
    jne divide_loop
    
print_digits:
    pop dx             
    add dl, 30h        
    mov ah, 2
    int 21h
    loop print_digits
    jmp print_done
    
single_digit:
    mov dl, al
    add dl, 30h       
    mov ah, 2
    int 21h
    
print_done:
    pop dx
    pop cx
    pop bx
    pop ax
    ret
print_num endp

end main