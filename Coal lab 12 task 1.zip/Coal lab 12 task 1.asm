.model small
.stack 100h
.data
.code
main proc
    mov ax, @data
    mov ds, ax

    mov cx, 4          

outer:
    push cx           
    mov bx, 1         

    mov cx, 5
    sub cx, bx        

    pop cx
    push cx

    mov dx, cx
    mov cx, 5
    sub cx, dx        

    mov si, cx       

    mov bx, 1

inner:
    mov dl, bl
    add dl, 30h       
    mov ah, 02h
    int 21h

    inc bl
    dec si
    jnz inner

    ; new line
    mov dl, 10
    mov ah, 02h
    int 21h
    mov dl, 13
    int 21h

    pop cx
    loop outer

    mov ah, 4Ch
    int 21h

main endp
end main


