.model small
.stack 100h
.data

.code
main proc
    mov ax, @data
    mov ds, ax

    mov cx, 5        

printA:
    mov dl, 'A'      
    mov ah, 02h
    int 21h
     
    mov dl, ' '      
    mov ah, 02h     
    int 21h          


    loop printA      

    mov ah, 4ch
    int 21h
main endp
end main




