.model small
.stack 100h
.data
msgG db 'Greater$'
msgS db 'Smaller$'
msgE db 'Equal$'

.code
main proc
    mov ax, @data
    mov ds, ax

    mov ah, 01h
    int 21h
    sub al, 30h
    mov bl, al     

    mov ah, 01h
    int 21h
    sub al, 30h
    mov bh, al       

    cmp bl, bh
    je equal
    jg greater
    jl smaller

greater:
    mov dx, offset msgG
    mov ah, 09h
    int 21h
    jmp end_prog

smaller:
    mov dx, offset msgS
    mov ah, 09h
    int 21h
    jmp end_prog

equal:
    mov dx, offset msgE
    mov ah, 09h
    int 21h

end_prog:
    mov ah, 4ch
    int 21h
main endp
end main



