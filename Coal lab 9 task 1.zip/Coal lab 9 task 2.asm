.model small
.stack 100h
.data
msg1 db 0Dh,0Ah,'Positive$'
msg2 db 0Dh,0Ah,'Negative$'

.code
main proc
    mov ax, @data
    mov ds, ax

    mov ah, 01h
    int 21h

    cmp al, '-'       
    je negative_case

    jmp positive_case 
    7

negative_case:
   
    mov ah, 01h
    int 21h

    mov dx, offset msg2
    mov ah, 09h
    int 21h
    jmp end_prog 
    

positive_case:
    mov dx, offset msg1
    mov ah, 09h
    int 21h

end_prog:
    mov ah, 4ch
    int 21h

main endp
end main




