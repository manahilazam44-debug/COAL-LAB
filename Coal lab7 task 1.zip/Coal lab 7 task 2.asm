.model small
.stack 100h
.data
msg1 db 'Cube of a number:$'

.code
main proc
    mov ax, @data
    mov ds, ax 
    
    mov al,5      
    mov bl,al
    mul bl       
    mul bl         

    mov dx,offset msg
    mov ah,09h
    int 21h

    mov ax,ax     
    mov bx,100
    xor dx,dx
    div bx         
    add al,30h
    mov dl,al
    mov ah,02h
    int 21h       

    mov ax,ah      
    mov bx,10
    xor dx,dx
    div bx         
    add al,30h
    mov dl,al
    mov ah,02h
    int 21h       

    add ah,30h
    mov dl,ah
    mov ah,02h
    int 21h  
    
    mov ah,4ch
    int 21h
    main endp
end main


