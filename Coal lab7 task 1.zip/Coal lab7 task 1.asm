.model small
.stack 100h
.data
msg1 db 'Area of rectangle: $'

.code
main proc
    mov ax,@data
    mov ds,ax

    mov al,5
    mov bl,6
    mul bl         

    mov bl,10
    div bl          

    add al,30h      
    mov dl,al
    mov ah,02h
    int 21h        

    mov al,ah       
    add al,30h      
    mov dl,al
    mov ah,02h
    int 21h        

    mov ah,4ch
    int 21h
main endp
end main