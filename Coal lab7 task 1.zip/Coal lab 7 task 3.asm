.model small
.stack 100h
.data
msg1 db 'Quotient: $'
msg2 db ' Remainder: $'

.code
main proc
    mov ax,@data
    mov ds,ax

    mov al, 47       
    mov bl, 10

    xor ah,ah       
    div bl          

    mov dx, offset msg1
    mov ah,09h
    int 21h

    add al,30h       
    mov dl,al
    mov ah,02h
    int 21h

    mov dx, offset msg2
    mov ah,09h
    int 21h

    add ah,30h       
    mov dl,ah
    mov ah,02h
    int 21h

    mov ah,4Ch
    int 21h
    main endp
end main


