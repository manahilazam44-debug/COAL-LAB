.model small
.stack 100h
.data
space db ' ','$'

.code
main proc
    mov ax,@data
    mov ds,ax

    mov dl, 0      

even_loop:
    add dl, 30h    
    mov ah, 02h
    int 21h
    sub dl, 30h  

   
    mov dl, ' '
    mov ah, 02h
    int 21h

    add dl, 0      
    add dl, 2     
    cmp dl, 10
    jl even_loop

    mov ah,4ch
    int 21h
main endp
end main




