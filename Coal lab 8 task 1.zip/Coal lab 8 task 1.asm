.model small
.stack 100h
.data
msg db '$'       

.code
main proc
    mov ax,@data
    mov ds,ax

    mov dl, 9      

rev_loop:
    add dl, 30h   
    mov ah, 02h    
    int 21h
    sub dl, 30h   
    dec dl         
    cmp dl, -1
    jg rev_loop

    mov ah,4ch
    int 21h
main endp
end main


