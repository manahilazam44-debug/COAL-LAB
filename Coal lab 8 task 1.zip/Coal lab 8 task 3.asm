.model small
.stack 100h
.data
newlinedb db 0dh,0ah,'$'

.code
main proc
    mov ax,@data
    mov ds,ax

    mov al, 'A'

print_letters:
    mov dl, al
    mov ah, 02h
    int 21h

    ; Print new line
    mov dx, offset newlinedb
    mov ah, 09h
    int 21h

    inc al
    cmp al, 'Z'+1
    jne print_letters

    mov ah, 4ch
    int 21h
main endp
end main




