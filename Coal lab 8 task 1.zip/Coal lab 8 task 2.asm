.model small
.stack 100h
.data
msg db '*','$'

.code
main proc
    mov ax,@data
    mov ds,ax

    mov cx, 5     

print_loop:
    mov dl, '*'   
    mov ah, 02h
    int 21h
    loop print_loop

    mov ah,4ch
    int 21h
main endp
end main


