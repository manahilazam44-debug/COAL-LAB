.model small
.stack 100h

.data
str db 'HELLO$'

.code
main proc
    mov ax, @data
    mov ds, ax

    mov si, offset str   
    mov cx, 0            

next_char:
    mov al, [si]
    cmp al, '$'
    je display_result

    push ax             
    inc cx            

    inc si               
    jmp next_char

display_result:
    mov al, cl
    add al, 30h        

    mov dl, al
    mov ah, 02h
    int 21h

    mov ah, 4ch
    int 21h

main endp
end main