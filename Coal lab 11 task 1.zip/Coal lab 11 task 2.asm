.model small
.stack 100h

.data
msg1 db 10,13,'Palindrome$'
msg2 db 10,13,'Not Palindrome$'

str db 20 dup('$')

.code
main proc
    mov ax, @data
    mov ds, ax

    mov si, offset str

input_loop:
    mov ah, 01h
    int 21h        

    cmp al, 13      
    je start_check

    mov [si], al
    push ax          
    inc si
    jmp input_loop

start_check:
    mov si, offset str

check_loop:
    mov al, [si]
    cmp al, '$'
    je palindrome

    pop bx
    cmp al, bl
    jne not_palindrome

    inc si
    jmp check_loop

palindrome:
    mov dx, offset msg1
    mov ah, 09h
    int 21h
    jmp exit

not_palindrome:
    mov dx, offset msg2
    mov ah, 09h
    int 21h

exit:
    mov ah, 4ch
    int 21h

main endp
end main




